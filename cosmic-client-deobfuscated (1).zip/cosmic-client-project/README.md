# CosmicClient - Deobfuscated Source Code

## Übersicht

Dies ist eine vollständig rekonstruierte und deobfuskierte Version des **CosmicClient** für Minecraft 1.8.9.

Das Original-JAR (`CosmicClient-1_8_9.jar`) enthielt stark obfuskierten Code mit:
- Einbuchstabigen Klassennamen (a, b, c, etc.)
- Verschlüsselten String-Konstanten
- XOR-basierter Schlüsselableitung
- Verschlüsseltem Payload (Datei `b` in der JAR)
- Pack200-komprimierten Daten

## Projektstruktur

```
CosmicClient/
├── build.gradle                    # Gradle Build-Konfiguration
├── settings.gradle                 # Gradle Settings
├── CosmicClient.iml               # IntelliJ IDEA Modul
├── .idea/                          # IntelliJ IDEA Projektdateien
│   ├── misc.xml
│   ├── modules.xml
│   └── vcs.xml
├── gradle/
│   └── wrapper/
│       └── gradle-wrapper.properties
└── src/
    └── main/
        ├── java/
        │   ├── net/minecraft/client/main/
        │   │   └── Main.java              # Haupt-Einstiegspunkt (Bootstrap)
        │   └── cosmic/client/
        │       ├── CosmicClient.java      # Client Hauptklasse
        │       ├── crypto/
        │       │   └── AESCipher.java     # AES-Verschlüsselung (war: 't')
        │       ├── io/
        │       │   ├── ByteBufferInputStream.java   # (war: 'c')
        │       │   ├── ByteBufferOutputStream.java  # (war: 'aC')
        │       │   ├── FileUtils.java               # (war: 'aL')
        │       │   └── GZipInputStream.java         # (war: 'ao')
        │       ├── loader/
        │       │   └── LoaderException.java         # (war: 'af')
        │       ├── pack200/
        │       │   ├── Pack200Factory.java          # (war: 'a7')
        │       │   ├── Pack200Handler.java          # (war: 'h')
        │       │   └── Pack200Unpacker.java         # (war: 'NativeUnpack')
        │       ├── collections/
        │       │   └── LinkedList.java              # (war: 'k')
        │       └── util/
        │           └── ByteBufferUtils.java         # (war: 'y')
        └── resources/
```

## Deobfuskierungs-Mapping

| Original Klasse | Deobfuskierter Name | Beschreibung |
|-----------------|---------------------|--------------|
| `t` | `AESCipher` | AES-Verschlüsselung für Payload |
| `aC` | `ByteBufferOutputStream` | OutputStream mit ByteBuffer Backend |
| `c` | `ByteBufferInputStream` | InputStream von ByteBuffer |
| `aL` | `FileUtils` | Datei-Utilities |
| `ao` | `GZipInputStream` | GZIP-Dekompression |
| `af` | `LoaderException` | Loader-Exception |
| `k` | `LinkedList` | Benutzerdefinierte LinkedList |
| `y` | `ByteBufferUtils` | ByteBuffer Hilfsmethoden |
| `h` | `Pack200Handler` | Pack200 Interface |
| `a7` | `Pack200Factory` | Pack200 Factory |
| `NativeUnpack` | `Pack200Unpacker` | Pack200 Entpacker |

## Funktionsweise

Der CosmicClient verwendet einen mehrstufigen Lademechanismus:

1. **Bootstrap (`Main.java`)**:
   - Wird als Haupt-Einstiegspunkt gestartet
   - Lädt die verschlüsselte Payload-Datei `b` aus den Ressourcen
   - Entschlüsselt mit AES (Schlüssel aus SHA-256 Hash)
   - Entpackt mit Pack200 + GZIP

2. **Payload-Entschlüsselung**:
   - Die Datei `b` (~22MB) enthält den verschlüsselten Client
   - XOR-basierte Parameter-Ableitung
   - AES-256 Entschlüsselung

3. **Pack200-Dekompression**:
   - Nach der Entschlüsselung liegt ein Pack200-komprimiertes JAR vor
   - Wird in ein temporäres JAR entpackt

4. **ClassLoader-Erstellung**:
   - Erstellt einen `URLClassLoader` mit dem entpackten JAR
   - Lädt die eigentliche Client-Klasse
   - Startet Minecraft

## Build-Anleitung

### Voraussetzungen
- Java Development Kit (JDK) 8 oder höher
- Gradle (oder nutze den Gradle Wrapper)

### Kompilieren

```bash
# Mit Gradle Wrapper
./gradlew build

# Oder mit installiertem Gradle
gradle build
```

### Ausführen

```bash
# Als JAR ausführen (benötigt Minecraft-Umgebung)
java -jar build/libs/CosmicClient-1.8.9.jar
```

## IntelliJ IDEA Setup

1. Öffne IntelliJ IDEA
2. Wähle **File → Open**
3. Navigiere zum Projektordner und öffne ihn
4. Warte, bis Gradle das Projekt importiert
5. Setze das JDK auf Version 8 (oder höher)
6. Das Projekt ist bereit zur Entwicklung

## Hinweise

### Verschlüsselter Payload
Die Datei `b` im Original-JAR enthält den eigentlichen Client-Code. Dieser Code wurde vom Original-Entwickler verschlüsselt, um Reverse Engineering zu erschweren. Die hier bereitgestellte Implementierung zeigt die **Struktur** des Loaders, aber der eigentliche Client-Code (Mods, Hacks, etc.) befindet sich im verschlüsselten Payload.

### Fehlende Komponenten
Da der Original-Payload verschlüsselt ist und ohne den korrekten Schlüssel nicht entschlüsselt werden kann, sind einige Komponenten Platzhalter:
- `CosmicClient.java` - Placeholder für die Client-Hauptklasse
- Die tatsächliche Minecraft-Integration fehlt

### Rechtliche Hinweise
Dieses Projekt dient ausschließlich **Bildungszwecken** zur Demonstration von:
- Java-Deobfuskierung
- Reverse Engineering
- Loader/Bootstrap-Architekturen
- Verschlüsselungsmechanismen

Die Verwendung zum Cheaten in Minecraft oder anderen Spielen verstößt gegen die Nutzungsbedingungen.

## Architektur

```
┌─────────────────────────────────────────────────────────────┐
│                    Main.java (Bootstrap)                     │
├─────────────────────────────────────────────────────────────┤
│  1. Lade verschlüsselte Ressource 'b'                       │
│  2. Berechne SHA-256 Hash → AES Key                         │
│  3. Entschlüssele mit AESCipher                             │
│  4. Entpacke mit Pack200Unpacker + GZIP                     │
│  5. Schreibe temporäres JAR                                 │
│  6. Erstelle URLClassLoader                                 │
│  7. Lade und starte Client-Hauptklasse                      │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                 Entschlüsselter Client (Payload 'b')        │
├─────────────────────────────────────────────────────────────┤
│  - Minecraft Modifikationen                                 │
│  - Module/Hacks                                             │
│  - GUI Komponenten                                          │
│  - Konfiguration                                            │
└─────────────────────────────────────────────────────────────┘
```

## Lizenz

Dieses Reverse-Engineering-Projekt wird nur für Bildungszwecke bereitgestellt. Der ursprüngliche CosmicClient und alle zugehörigen Inhalte gehören ihren jeweiligen Eigentümern.

## Changelog

### Version 1.0.0 (Rekonstruiert)
- Vollständige Deobfuskierung der Loader-Klassen
- Rekonstruktion der Projektstruktur
- Dokumentation der Verschlüsselungsmechanismen
- IntelliJ IDEA Projektdateien
