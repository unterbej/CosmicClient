package cosmic.client.crypto;

import java.nio.ByteBuffer;
import java.security.MessageDigest;
import java.util.Arrays;

/**
 * AES Cipher Implementation for CosmicClient
 * 
 * This class handles AES encryption/decryption of the payload data.
 * Deobfuscated from original class 't'.
 * 
 * The cipher uses a custom key derivation scheme based on string passwords
 * or raw byte arrays, with configurable parameters.
 */
public class AESCipher {
    
    /** Encryption round keys (derived from password) */
    private final int[] encryptionKeys;
    
    /** Decryption round keys (inverse of encryption keys) */
    private final int[] decryptionKeys;
    
    /** Flag indicating encryption mode (true) or decryption mode (false) */
    private final boolean encryptionMode;
    
    /** Debug/logging flag */
    public static boolean debugEnabled;
    
    /** S-Box for AES substitution */
    private static final int[] SBOX = {
        0x63, 0x7c, 0x77, 0x7b, 0xf2, 0x6b, 0x6f, 0xc5, 0x30, 0x01, 0x67, 0x2b, 0xfe, 0xd7, 0xab, 0x76,
        0xca, 0x82, 0xc9, 0x7d, 0xfa, 0x59, 0x47, 0xf0, 0xad, 0xd4, 0xa2, 0xaf, 0x9c, 0xa4, 0x72, 0xc0,
        0xb7, 0xfd, 0x93, 0x26, 0x36, 0x3f, 0xf7, 0xcc, 0x34, 0xa5, 0xe5, 0xf1, 0x71, 0xd8, 0x31, 0x15,
        0x04, 0xc7, 0x23, 0xc3, 0x18, 0x96, 0x05, 0x9a, 0x07, 0x12, 0x80, 0xe2, 0xeb, 0x27, 0xb2, 0x75,
        0x09, 0x83, 0x2c, 0x1a, 0x1b, 0x6e, 0x5a, 0xa0, 0x52, 0x3b, 0xd6, 0xb3, 0x29, 0xe3, 0x2f, 0x84,
        0x53, 0xd1, 0x00, 0xed, 0x20, 0xfc, 0xb1, 0x5b, 0x6a, 0xcb, 0xbe, 0x39, 0x4a, 0x4c, 0x58, 0xcf,
        0xd0, 0xef, 0xaa, 0xfb, 0x43, 0x4d, 0x33, 0x85, 0x45, 0xf9, 0x02, 0x7f, 0x50, 0x3c, 0x9f, 0xa8,
        0x51, 0xa3, 0x40, 0x8f, 0x92, 0x9d, 0x38, 0xf5, 0xbc, 0xb6, 0xda, 0x21, 0x10, 0xff, 0xf3, 0xd2,
        0xcd, 0x0c, 0x13, 0xec, 0x5f, 0x97, 0x44, 0x17, 0xc4, 0xa7, 0x7e, 0x3d, 0x64, 0x5d, 0x19, 0x73,
        0x60, 0x81, 0x4f, 0xdc, 0x22, 0x2a, 0x90, 0x88, 0x46, 0xee, 0xb8, 0x14, 0xde, 0x5e, 0x0b, 0xdb,
        0xe0, 0x32, 0x3a, 0x0a, 0x49, 0x06, 0x24, 0x5c, 0xc2, 0xd3, 0xac, 0x62, 0x91, 0x95, 0xe4, 0x79,
        0xe7, 0xc8, 0x37, 0x6d, 0x8d, 0xd5, 0x4e, 0xa9, 0x6c, 0x56, 0xf4, 0xea, 0x65, 0x7a, 0xae, 0x08,
        0xba, 0x78, 0x25, 0x2e, 0x1c, 0xa6, 0xb4, 0xc6, 0xe8, 0xdd, 0x74, 0x1f, 0x4b, 0xbd, 0x8b, 0x8a,
        0x70, 0x3e, 0xb5, 0x66, 0x48, 0x03, 0xf6, 0x0e, 0x61, 0x35, 0x57, 0xb9, 0x86, 0xc1, 0x1d, 0x9e,
        0xe1, 0xf8, 0x98, 0x11, 0x69, 0xd9, 0x8e, 0x94, 0x9b, 0x1e, 0x87, 0xe9, 0xce, 0x55, 0x28, 0xdf,
        0x8c, 0xa1, 0x89, 0x0d, 0xbf, 0xe6, 0x42, 0x68, 0x41, 0x99, 0x2d, 0x0f, 0xb0, 0x54, 0xbb, 0x16
    };
    
    /** Inverse S-Box for AES inverse substitution */
    private static final int[] INV_SBOX = {
        0x52, 0x09, 0x6a, 0xd5, 0x30, 0x36, 0xa5, 0x38, 0xbf, 0x40, 0xa3, 0x9e, 0x81, 0xf3, 0xd7, 0xfb,
        0x7c, 0xe3, 0x39, 0x82, 0x9b, 0x2f, 0xff, 0x87, 0x34, 0x8e, 0x43, 0x44, 0xc4, 0xde, 0xe9, 0xcb,
        0x54, 0x7b, 0x94, 0x32, 0xa6, 0xc2, 0x23, 0x3d, 0xee, 0x4c, 0x95, 0x0b, 0x42, 0xfa, 0xc3, 0x4e,
        0x08, 0x2e, 0xa1, 0x66, 0x28, 0xd9, 0x24, 0xb2, 0x76, 0x5b, 0xa2, 0x49, 0x6d, 0x8b, 0xd1, 0x25,
        0x72, 0xf8, 0xf6, 0x64, 0x86, 0x68, 0x98, 0x16, 0xd4, 0xa4, 0x5c, 0xcc, 0x5d, 0x65, 0xb6, 0x92,
        0x6c, 0x70, 0x48, 0x50, 0xfd, 0xed, 0xb9, 0xda, 0x5e, 0x15, 0x46, 0x57, 0xa7, 0x8d, 0x9d, 0x84,
        0x90, 0xd8, 0xab, 0x00, 0x8c, 0xbc, 0xd3, 0x0a, 0xf7, 0xe4, 0x58, 0x05, 0xb8, 0xb3, 0x45, 0x06,
        0xd0, 0x2c, 0x1e, 0x8f, 0xca, 0x3f, 0x0f, 0x02, 0xc1, 0xaf, 0xbd, 0x03, 0x01, 0x13, 0x8a, 0x6b,
        0x3a, 0x91, 0x11, 0x41, 0x4f, 0x67, 0xdc, 0xea, 0x97, 0xf2, 0xcf, 0xce, 0xf0, 0xb4, 0xe6, 0x73,
        0x96, 0xac, 0x74, 0x22, 0xe7, 0xad, 0x35, 0x85, 0xe2, 0xf9, 0x37, 0xe8, 0x1c, 0x75, 0xdf, 0x6e,
        0x47, 0xf1, 0x1a, 0x71, 0x1d, 0x29, 0xc5, 0x89, 0x6f, 0xb7, 0x62, 0x0e, 0xaa, 0x18, 0xbe, 0x1b,
        0xfc, 0x56, 0x3e, 0x4b, 0xc6, 0xd2, 0x79, 0x20, 0x9a, 0xdb, 0xc0, 0xfe, 0x78, 0xcd, 0x5a, 0xf4,
        0x1f, 0xdd, 0xa8, 0x33, 0x88, 0x07, 0xc7, 0x31, 0xb1, 0x12, 0x10, 0x59, 0x27, 0x80, 0xec, 0x5f,
        0x60, 0x51, 0x7f, 0xa9, 0x19, 0xb5, 0x4a, 0x0d, 0x2d, 0xe5, 0x7a, 0x9f, 0x93, 0xc9, 0x9c, 0xef,
        0xa0, 0xe0, 0x3b, 0x4d, 0xae, 0x2a, 0xf5, 0xb0, 0xc8, 0xeb, 0xbb, 0x3c, 0x83, 0x53, 0x99, 0x61,
        0x17, 0x2b, 0x04, 0x7e, 0xba, 0x77, 0xd6, 0x26, 0xe1, 0x69, 0x14, 0x63, 0x55, 0x21, 0x0c, 0x7d
    };
    
    /** Round constants for key expansion */
    private static final int[] RCON = {
        0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80, 0x1b, 0x36
    };
    
    /**
     * Create a new AES cipher from a password string
     * 
     * @param password Password to derive key from
     * @param encryptMode True for encryption, false for decryption
     */
    public AESCipher(String password, boolean encryptMode) {
        this.encryptionMode = encryptMode;
        
        // Derive key from password using SHA-256
        byte[] keyBytes = deriveKeyFromPassword(password);
        
        // Expand key to round keys
        this.encryptionKeys = expandKey(keyBytes);
        this.decryptionKeys = invertKeys(encryptionKeys);
    }
    
    /**
     * Create a new AES cipher from raw key bytes
     * 
     * @param keyBytes Raw key bytes
     * @param param1 Configuration parameter
     * @param param2 Configuration parameter  
     * @param param3 Configuration parameter
     * @param encryptMode True for encryption, false for decryption
     */
    public AESCipher(byte[] keyBytes, char param1, int param2, char param3, boolean encryptMode) {
        this.encryptionMode = encryptMode;
        
        // Ensure key is correct length (16, 24, or 32 bytes)
        byte[] normalizedKey = normalizeKey(keyBytes);
        
        this.encryptionKeys = expandKey(normalizedKey);
        this.decryptionKeys = invertKeys(encryptionKeys);
    }
    
    /**
     * Create a new AES cipher from ByteBuffer
     * 
     * @param keyBuffer Buffer containing key data
     * @param param1 Configuration parameter
     * @param encryptMode Encryption mode flag
     * @param param3 Configuration parameter
     * @param param4 Configuration parameter
     */
    public AESCipher(ByteBuffer keyBuffer, short param1, boolean encryptMode, short param3, int param4) {
        this.encryptionMode = encryptMode;
        
        byte[] keyBytes = new byte[Math.min(32, keyBuffer.remaining())];
        keyBuffer.duplicate().get(keyBytes);
        
        byte[] normalizedKey = normalizeKey(keyBytes);
        this.encryptionKeys = expandKey(normalizedKey);
        this.decryptionKeys = invertKeys(encryptionKeys);
    }
    
    /**
     * Derive a 256-bit key from password using SHA-256
     * 
     * @param password Input password
     * @return 32-byte key
     */
    private byte[] deriveKeyFromPassword(String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            return md.digest(password.getBytes("UTF-8"));
        } catch (Exception e) {
            // Fallback: simple hash
            byte[] result = new byte[32];
            byte[] passBytes = password.getBytes();
            for (int i = 0; i < 32; i++) {
                result[i] = passBytes[i % passBytes.length];
            }
            return result;
        }
    }
    
    /**
     * Normalize key to standard AES key length
     * 
     * @param keyBytes Input key bytes
     * @return Normalized 16, 24, or 32 byte key
     */
    private byte[] normalizeKey(byte[] keyBytes) {
        if (keyBytes.length >= 32) {
            return Arrays.copyOf(keyBytes, 32);
        } else if (keyBytes.length >= 24) {
            return Arrays.copyOf(keyBytes, 24);
        } else {
            return Arrays.copyOf(keyBytes, 16);
        }
    }
    
    /**
     * Expand key into round keys
     * 
     * @param key Original key
     * @return Expanded round keys
     */
    private int[] expandKey(byte[] key) {
        int keyLen = key.length;
        int rounds = keyLen / 4 + 6;
        int[] w = new int[(rounds + 1) * 4];
        
        // Copy original key
        for (int i = 0; i < keyLen / 4; i++) {
            w[i] = ((key[4 * i] & 0xFF) << 24) |
                   ((key[4 * i + 1] & 0xFF) << 16) |
                   ((key[4 * i + 2] & 0xFF) << 8) |
                   (key[4 * i + 3] & 0xFF);
        }
        
        // Expand key
        int nk = keyLen / 4;
        for (int i = nk; i < w.length; i++) {
            int temp = w[i - 1];
            if (i % nk == 0) {
                temp = subWord(rotWord(temp)) ^ (RCON[i / nk - 1] << 24);
            } else if (nk > 6 && i % nk == 4) {
                temp = subWord(temp);
            }
            w[i] = w[i - nk] ^ temp;
        }
        
        return w;
    }
    
    /**
     * Invert encryption keys for decryption
     */
    private int[] invertKeys(int[] encKeys) {
        int[] decKeys = new int[encKeys.length];
        int rounds = encKeys.length / 4 - 1;
        
        // Copy first and last round keys
        System.arraycopy(encKeys, 0, decKeys, rounds * 4, 4);
        System.arraycopy(encKeys, rounds * 4, decKeys, 0, 4);
        
        // Inverse mix columns for middle rounds
        for (int round = 1; round < rounds; round++) {
            for (int i = 0; i < 4; i++) {
                decKeys[(rounds - round) * 4 + i] = invMixColumn(encKeys[round * 4 + i]);
            }
        }
        
        return decKeys;
    }
    
    /**
     * Decrypt data
     * 
     * @param param1 Parameter 1
     * @param param2 Parameter 2
     * @param param3 Parameter 3
     * @param input Input data
     * @param param5 Parameter 5
     * @return Decrypted data
     */
    public ByteBuffer decrypt(int param1, int param2, char param3, ByteBuffer input, boolean param5) {
        int inputLen = input.remaining();
        ByteBuffer output = ByteBuffer.allocate(inputLen);
        
        byte[] block = new byte[16];
        byte[] outBlock = new byte[16];
        
        while (input.remaining() >= 16) {
            input.get(block);
            decryptBlock(block, outBlock);
            output.put(outBlock);
        }
        
        // Handle remaining bytes (padding)
        if (input.hasRemaining()) {
            int remaining = input.remaining();
            Arrays.fill(block, (byte) 0);
            input.get(block, 0, remaining);
            decryptBlock(block, outBlock);
            output.put(outBlock, 0, remaining);
        }
        
        output.flip();
        return output;
    }
    
    /**
     * Decrypt a single 16-byte block
     */
    private void decryptBlock(byte[] input, byte[] output) {
        int[] state = new int[4];
        
        // Convert input to state
        for (int i = 0; i < 4; i++) {
            state[i] = ((input[4 * i] & 0xFF) << 24) |
                       ((input[4 * i + 1] & 0xFF) << 16) |
                       ((input[4 * i + 2] & 0xFF) << 8) |
                       (input[4 * i + 3] & 0xFF);
        }
        
        int rounds = decryptionKeys.length / 4 - 1;
        
        // Initial round key addition
        for (int i = 0; i < 4; i++) {
            state[i] ^= decryptionKeys[i];
        }
        
        // Main rounds
        for (int round = 1; round < rounds; round++) {
            state = invRound(state, round * 4);
        }
        
        // Final round (no mix columns)
        state = invFinalRound(state, rounds * 4);
        
        // Convert state to output
        for (int i = 0; i < 4; i++) {
            output[4 * i] = (byte) (state[i] >>> 24);
            output[4 * i + 1] = (byte) (state[i] >>> 16);
            output[4 * i + 2] = (byte) (state[i] >>> 8);
            output[4 * i + 3] = (byte) state[i];
        }
    }
    
    /**
     * Inverse round transformation
     */
    private int[] invRound(int[] state, int keyOffset) {
        int[] newState = new int[4];
        
        // Inverse shift rows + inverse sub bytes + add round key + inverse mix columns
        for (int i = 0; i < 4; i++) {
            int col = 0;
            for (int j = 0; j < 4; j++) {
                int shiftedIndex = (i + j) % 4;
                int byteVal = (state[shiftedIndex] >>> (24 - j * 8)) & 0xFF;
                col |= INV_SBOX[byteVal] << (24 - j * 8);
            }
            newState[i] = invMixColumn(col ^ decryptionKeys[keyOffset + i]);
        }
        
        return newState;
    }
    
    /**
     * Inverse final round transformation
     */
    private int[] invFinalRound(int[] state, int keyOffset) {
        int[] newState = new int[4];
        
        for (int i = 0; i < 4; i++) {
            int col = 0;
            for (int j = 0; j < 4; j++) {
                int shiftedIndex = (i + j) % 4;
                int byteVal = (state[shiftedIndex] >>> (24 - j * 8)) & 0xFF;
                col |= INV_SBOX[byteVal] << (24 - j * 8);
            }
            newState[i] = col ^ decryptionKeys[keyOffset + i];
        }
        
        return newState;
    }
    
    // AES helper methods
    
    private static int subWord(int word) {
        return (SBOX[(word >>> 24) & 0xFF] << 24) |
               (SBOX[(word >>> 16) & 0xFF] << 16) |
               (SBOX[(word >>> 8) & 0xFF] << 8) |
               SBOX[word & 0xFF];
    }
    
    private static int rotWord(int word) {
        return (word << 8) | ((word >>> 24) & 0xFF);
    }
    
    private static int invMixColumn(int col) {
        int b0 = (col >>> 24) & 0xFF;
        int b1 = (col >>> 16) & 0xFF;
        int b2 = (col >>> 8) & 0xFF;
        int b3 = col & 0xFF;
        
        return (mul(0x0e, b0) ^ mul(0x0b, b1) ^ mul(0x0d, b2) ^ mul(0x09, b3)) << 24 |
               (mul(0x09, b0) ^ mul(0x0e, b1) ^ mul(0x0b, b2) ^ mul(0x0d, b3)) << 16 |
               (mul(0x0d, b0) ^ mul(0x09, b1) ^ mul(0x0e, b2) ^ mul(0x0b, b3)) << 8 |
               (mul(0x0b, b0) ^ mul(0x0d, b1) ^ mul(0x09, b2) ^ mul(0x0e, b3));
    }
    
    private static int mul(int a, int b) {
        int result = 0;
        int temp = b;
        for (int i = 0; i < 8; i++) {
            if ((a & (1 << i)) != 0) {
                result ^= temp;
            }
            boolean highBit = (temp & 0x80) != 0;
            temp <<= 1;
            if (highBit) {
                temp ^= 0x1b;
            }
        }
        return result & 0xFF;
    }
}
