package cosmic.client.crypto;

/**
 * String Decryptor for obfuscated string constants.
 * 
 * The original obfuscated code uses XOR-based string encryption
 * with various magic constants to hide string literals.
 * 
 * This class provides methods to decrypt those strings.
 */
public final class StringDecryptor {
    
    /** Magic constants used in string decryption */
    private static final long[] MAGIC_CONSTANTS = {
        112218500967331L,
        60348117292003L,
        105498286026252L,
        35021413042539L,
        106283409302420L
    };
    
    /** Additional integer constants */
    private static final int[] INT_CONSTANTS = {
        2147483647,
        65535,
        -1004258340,
        1004389410,
        -1004389410,
        1004258340,
        -1192474860,
        1192474860,
        -893373120
    };
    
    private StringDecryptor() {
        // Utility class
    }
    
    /**
     * Decrypt a string using the standard XOR method.
     * 
     * @param param1 First parameter
     * @param param2 Second parameter  
     * @param param3 Third parameter
     * @return Decrypted string
     */
    public static String decrypt(int param1, int param2, int param3) {
        // This method reconstructs the string decryption logic
        // from the original obfuscated code
        
        // The original uses complex XOR operations with the parameters
        // to derive indices into encrypted string arrays
        
        long combined = ((long) param1 << 32) | (param2 & 0xFFFFFFFFL);
        long decrypted = combined ^ MAGIC_CONSTANTS[param3 % MAGIC_CONSTANTS.length];
        
        int index1 = (int) (decrypted >>> 48);
        int index2 = (int) ((decrypted << 16) >>> 48);
        int index3 = (int) ((decrypted << 32) >>> 32);
        
        // Return placeholder - actual implementation would look up
        // from encrypted string tables
        return "decrypted_string_" + index1 + "_" + index2 + "_" + index3;
    }
    
    /**
     * Decrypt a character array to string.
     * 
     * @param encrypted Encrypted character array
     * @param key Decryption key
     * @return Decrypted string
     */
    public static String decryptChars(char[] encrypted, int key) {
        char[] decrypted = new char[encrypted.length];
        
        for (int i = 0; i < encrypted.length; i++) {
            decrypted[i] = (char) (encrypted[i] ^ (key >>> (i % 4 * 8)));
        }
        
        return new String(decrypted);
    }
    
    /**
     * Decrypt a byte array to string.
     * 
     * @param encrypted Encrypted bytes
     * @param key Decryption key
     * @return Decrypted string
     */
    public static String decryptBytes(byte[] encrypted, long key) {
        byte[] decrypted = new byte[encrypted.length];
        
        for (int i = 0; i < encrypted.length; i++) {
            decrypted[i] = (byte) (encrypted[i] ^ (key >>> (i % 8 * 8)));
        }
        
        try {
            return new String(decrypted, "UTF-8");
        } catch (Exception e) {
            return new String(decrypted);
        }
    }
    
    /**
     * Apply XOR transformation with magic constants.
     * 
     * @param input Input value
     * @param constantIndex Index into magic constants array
     * @return Transformed value
     */
    public static long applyMagic(long input, int constantIndex) {
        return input ^ MAGIC_CONSTANTS[constantIndex % MAGIC_CONSTANTS.length];
    }
    
    /**
     * Derive parameters from a combined long value.
     * 
     * @param combined Combined long value
     * @return Array of derived parameters [high16, mid16, low32]
     */
    public static int[] deriveParameters(long combined) {
        return new int[] {
            (int) (combined >>> 48),
            (int) ((combined << 16) >>> 48),
            (int) ((combined << 32) >>> 32)
        };
    }
}
