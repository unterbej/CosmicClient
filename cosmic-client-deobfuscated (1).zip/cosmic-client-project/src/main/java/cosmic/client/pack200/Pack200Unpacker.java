package cosmic.client.pack200;

import java.io.*;
import java.nio.ByteBuffer;
import java.util.jar.JarEntry;
import java.util.jar.JarOutputStream;
import java.util.zip.CRC32;
import java.util.zip.Inflater;
import java.util.zip.InflaterInputStream;

/**
 * Pack200 Unpacker Implementation.
 * 
 * Deobfuscated from original class 'dev.architectury.pack200.java.NativeUnpack'.
 * 
 * Pack200 is a highly efficient compression scheme for JAR files.
 * This implementation handles:
 * - Reading Pack200 segment headers
 * - Decompressing class files
 * - Reconstructing the original JAR structure
 * 
 * Note: This is a simplified reconstruction. The original implementation
 * uses native code and complex bytecode manipulation.
 */
public class Pack200Unpacker implements Pack200Handler {
    
    /** Configuration parameter 1 */
    private final char configParam1;
    
    /** Configuration parameter 2 */
    private final short configParam2;
    
    /** Configuration parameter 3 */
    private final int configParam3;
    
    /** Buffer for reading data */
    private byte[] readBuffer;
    
    /** CRC calculator for verification */
    private final CRC32 crc;
    
    /** Current segment being processed */
    private int currentSegment;
    
    /** Total bytes processed */
    private long bytesProcessed;
    
    /** Debug flag */
    static final boolean DEBUG = false;
    
    /**
     * Create a new Pack200Unpacker with the specified configuration.
     * 
     * @param param1 First configuration parameter
     * @param param2 Second configuration parameter
     * @param param3 Third configuration parameter
     */
    public Pack200Unpacker(char param1, short param2, int param3) {
        this.configParam1 = param1;
        this.configParam2 = param2;
        this.configParam3 = param3;
        this.crc = new CRC32();
        this.readBuffer = new byte[65536];
        this.currentSegment = 0;
        this.bytesProcessed = 0;
    }
    
    @Override
    public void unpack(int param1, InputStream input, char param3, int param4, 
                      JarOutputStream output) throws IOException {
        
        BufferedInputStream bufferedInput = new BufferedInputStream(input, 65536);
        
        try {
            // Read Pack200 header and process segments
            processPackData(bufferedInput, output);
        } catch (Exception e) {
            if (e instanceof IOException) {
                throw (IOException) e;
            }
            throw new IOException("Pack200 unpacking failed: " + e.getMessage(), e);
        }
    }
    
    /**
     * Process Pack200 compressed data.
     * 
     * @param input Input stream with Pack200 data
     * @param output JAR output stream
     * @throws IOException If processing fails
     */
    private void processPackData(InputStream input, JarOutputStream output) throws IOException {
        // Read the magic number and version
        byte[] header = new byte[4];
        int read = input.read(header);
        
        if (read < 4) {
            throw new IOException("Invalid Pack200 data: header too short");
        }
        
        // Check for Pack200 magic number (0xCAFED00D) or custom format
        // The original CosmicClient uses a custom format, so we handle both
        
        if (isPack200Magic(header)) {
            // Standard Pack200 format
            unpackStandardPack200(input, output, header);
        } else {
            // Custom format - treat as raw JAR data
            unpackCustomFormat(input, output, header);
        }
    }
    
    /**
     * Check if the header contains Pack200 magic number.
     */
    private boolean isPack200Magic(byte[] header) {
        // Pack200 magic: 0xCAFED00D
        return header[0] == (byte) 0xCA && 
               header[1] == (byte) 0xFE && 
               header[2] == (byte) 0xD0 && 
               header[3] == (byte) 0x0D;
    }
    
    /**
     * Unpack standard Pack200 format.
     */
    private void unpackStandardPack200(InputStream input, JarOutputStream output, 
                                       byte[] header) throws IOException {
        // Read version info
        int minorVersion = readUnsignedByte(input);
        int majorVersion = readUnsignedByte(input);
        
        if (DEBUG) {
            System.out.println("Pack200 version: " + majorVersion + "." + minorVersion);
        }
        
        // Process segments
        while (true) {
            try {
                if (!processSegment(input, output)) {
                    break;
                }
                currentSegment++;
            } catch (EOFException e) {
                // Normal end of stream
                break;
            }
        }
    }
    
    /**
     * Unpack custom format (raw or minimally compressed JAR).
     */
    private void unpackCustomFormat(InputStream input, JarOutputStream output, 
                                   byte[] header) throws IOException {
        // Create a combined stream with header + rest of input
        ByteArrayInputStream headerStream = new ByteArrayInputStream(header);
        SequenceInputStream combined = new SequenceInputStream(headerStream, input);
        
        // Check if it's a ZIP/JAR file
        if (isZipMagic(header)) {
            // It's already a JAR file, just copy entries
            copyJarEntries(combined, output);
        } else {
            // Unknown format - try to process as raw data
            // This might be custom encrypted/compressed data
            processRawData(combined, output);
        }
    }
    
    /**
     * Check if header is ZIP magic number.
     */
    private boolean isZipMagic(byte[] header) {
        return header[0] == 'P' && header[1] == 'K' && 
               header[2] == 0x03 && header[3] == 0x04;
    }
    
    /**
     * Process a single Pack200 segment.
     * 
     * @return True if more segments may follow, false if done
     */
    private boolean processSegment(InputStream input, JarOutputStream output) 
            throws IOException {
        // Read segment header
        int segmentType = readUnsignedByte(input);
        
        if (segmentType == 0) {
            // End of segments
            return false;
        }
        
        // Read entry count
        int entryCount = readPackedInt(input);
        
        if (DEBUG) {
            System.out.println("Segment " + currentSegment + ": type=" + segmentType + 
                             ", entries=" + entryCount);
        }
        
        // Process entries in this segment
        for (int i = 0; i < entryCount; i++) {
            processEntry(input, output);
        }
        
        return true;
    }
    
    /**
     * Process a single JAR entry from Pack200 data.
     */
    private void processEntry(InputStream input, JarOutputStream output) throws IOException {
        // Read entry name
        String entryName = readPackedString(input);
        
        // Read entry metadata
        long modTime = readPackedLong(input);
        long size = readPackedLong(input);
        long compressedSize = readPackedLong(input);
        int method = readUnsignedByte(input);
        
        // Read entry data
        byte[] data = readEntryData(input, compressedSize, size, method);
        
        // Write to output JAR
        JarEntry entry = new JarEntry(entryName);
        entry.setTime(modTime);
        
        if (method == 0) {
            // Stored (no compression)
            entry.setMethod(JarEntry.STORED);
            entry.setSize(size);
            entry.setCompressedSize(size);
            crc.reset();
            crc.update(data);
            entry.setCrc(crc.getValue());
        }
        
        output.putNextEntry(entry);
        output.write(data);
        output.closeEntry();
        
        bytesProcessed += data.length;
    }
    
    /**
     * Read entry data, decompressing if necessary.
     */
    private byte[] readEntryData(InputStream input, long compressedSize, 
                                long uncompressedSize, int method) throws IOException {
        byte[] compressedData = new byte[(int) compressedSize];
        readFully(input, compressedData);
        
        if (method == 0 || compressedSize == uncompressedSize) {
            // Already uncompressed
            return compressedData;
        }
        
        // Decompress using Inflater
        Inflater inflater = new Inflater();
        try {
            inflater.setInput(compressedData);
            byte[] uncompressedData = new byte[(int) uncompressedSize];
            int resultLength = inflater.inflate(uncompressedData);
            
            if (resultLength != uncompressedSize) {
                throw new IOException("Decompression size mismatch: expected " + 
                    uncompressedSize + ", got " + resultLength);
            }
            
            return uncompressedData;
        } catch (Exception e) {
            throw new IOException("Decompression failed", e);
        } finally {
            inflater.end();
        }
    }
    
    /**
     * Copy entries from one JAR stream to another.
     */
    private void copyJarEntries(InputStream input, JarOutputStream output) throws IOException {
        java.util.jar.JarInputStream jarInput = new java.util.jar.JarInputStream(input);
        JarEntry entry;
        
        while ((entry = jarInput.getNextJarEntry()) != null) {
            // Read entry data
            ByteArrayOutputStream entryData = new ByteArrayOutputStream();
            byte[] buffer = new byte[8192];
            int bytesRead;
            
            while ((bytesRead = jarInput.read(buffer)) != -1) {
                entryData.write(buffer, 0, bytesRead);
            }
            
            // Write to output
            JarEntry newEntry = new JarEntry(entry.getName());
            newEntry.setTime(entry.getTime());
            
            if (entry.getMethod() == JarEntry.STORED) {
                newEntry.setMethod(JarEntry.STORED);
                newEntry.setSize(entry.getSize());
                newEntry.setCompressedSize(entry.getCompressedSize());
                newEntry.setCrc(entry.getCrc());
            }
            
            output.putNextEntry(newEntry);
            output.write(entryData.toByteArray());
            output.closeEntry();
        }
        
        jarInput.close();
    }
    
    /**
     * Process raw data that isn't in a recognized format.
     */
    private void processRawData(InputStream input, JarOutputStream output) throws IOException {
        // Read all data
        ByteArrayOutputStream buffer = new ByteArrayOutputStream();
        byte[] chunk = new byte[8192];
        int bytesRead;
        
        while ((bytesRead = input.read(chunk)) != -1) {
            buffer.write(chunk, 0, bytesRead);
        }
        
        byte[] data = buffer.toByteArray();
        
        // Try to interpret as class file
        if (data.length > 4 && data[0] == (byte) 0xCA && data[1] == (byte) 0xFE &&
            data[2] == (byte) 0xBA && data[3] == (byte) 0xBE) {
            // It's a class file
            JarEntry entry = new JarEntry("classes/UnpackedClass.class");
            output.putNextEntry(entry);
            output.write(data);
            output.closeEntry();
        } else {
            // Unknown data - store as resource
            JarEntry entry = new JarEntry("data/unpacked.bin");
            output.putNextEntry(entry);
            output.write(data);
            output.closeEntry();
        }
    }
    
    // Utility methods for reading packed integers and strings
    
    private int readUnsignedByte(InputStream input) throws IOException {
        int b = input.read();
        if (b < 0) {
            throw new EOFException();
        }
        return b;
    }
    
    private int readPackedInt(InputStream input) throws IOException {
        int result = 0;
        int shift = 0;
        int b;
        
        do {
            b = readUnsignedByte(input);
            result |= (b & 0x7F) << shift;
            shift += 7;
        } while ((b & 0x80) != 0);
        
        return result;
    }
    
    private long readPackedLong(InputStream input) throws IOException {
        long result = 0;
        int shift = 0;
        int b;
        
        do {
            b = readUnsignedByte(input);
            result |= (long) (b & 0x7F) << shift;
            shift += 7;
        } while ((b & 0x80) != 0);
        
        return result;
    }
    
    private String readPackedString(InputStream input) throws IOException {
        int length = readPackedInt(input);
        byte[] bytes = new byte[length];
        readFully(input, bytes);
        return new String(bytes, "UTF-8");
    }
    
    private void readFully(InputStream input, byte[] buffer) throws IOException {
        int offset = 0;
        while (offset < buffer.length) {
            int bytesRead = input.read(buffer, offset, buffer.length - offset);
            if (bytesRead < 0) {
                throw new EOFException("Unexpected end of stream");
            }
            offset += bytesRead;
        }
    }
    
    /**
     * Get the number of bytes processed so far.
     */
    public long getBytesProcessed() {
        return bytesProcessed;
    }
    
    /**
     * Get the current segment number.
     */
    public int getCurrentSegment() {
        return currentSegment;
    }
}
