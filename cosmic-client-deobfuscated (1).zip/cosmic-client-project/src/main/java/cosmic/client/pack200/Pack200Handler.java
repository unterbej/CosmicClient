package cosmic.client.pack200;

import java.io.IOException;
import java.io.InputStream;
import java.util.jar.JarOutputStream;

/**
 * Interface for Pack200 unpacking handlers.
 * 
 * Deobfuscated from original interface 'dev.architectury.pack200.java.h'.
 * 
 * Pack200 is a compression format specifically designed for JAR files.
 * This interface defines the contract for different unpacker implementations.
 */
public interface Pack200Handler {
    
    /**
     * Unpack compressed Pack200 data to a JAR output stream.
     * 
     * @param param1 First configuration parameter (typically related to segment handling)
     * @param input Input stream containing Pack200 compressed data
     * @param param3 Third configuration parameter (typically a flag)
     * @param param4 Fourth configuration parameter (typically segment size)
     * @param output JAR output stream to write unpacked entries to
     * @throws IOException If an I/O error occurs during unpacking
     */
    void unpack(int param1, InputStream input, char param3, int param4, JarOutputStream output) 
        throws IOException;
}
