package cosmic.client.io;

import java.io.*;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;

/**
 * File utility methods for CosmicClient.
 * 
 * Deobfuscated from original class 'aL'.
 * 
 * Provides methods for:
 * - Reading streams into ByteBuffers
 * - Writing ByteBuffers to files
 */
public final class FileUtils {
    
    /** Default buffer size for reading */
    private static final int DEFAULT_BUFFER_SIZE = 8192;
    
    /** Maximum buffer size before switching to chunked reading */
    private static final int MAX_BUFFER_SIZE = 64 * 1024 * 1024; // 64 MB
    
    private FileUtils() {
        // Utility class - no instantiation
    }
    
    /**
     * Write a ByteBuffer to a file
     * 
     * @param path Target file path
     * @param buffer Data to write
     * @throws IOException If writing fails
     */
    public static void writeToFile(Path path, ByteBuffer buffer) throws IOException {
        // Ensure buffer is ready for reading
        ByteBuffer toWrite = buffer.duplicate();
        if (toWrite.position() > 0 && toWrite.limit() == toWrite.capacity()) {
            toWrite.flip();
        }
        
        try (FileChannel channel = FileChannel.open(path, 
                StandardOpenOption.CREATE, 
                StandardOpenOption.WRITE, 
                StandardOpenOption.TRUNCATE_EXISTING)) {
            while (toWrite.hasRemaining()) {
                channel.write(toWrite);
            }
        }
    }
    
    /**
     * Read an entire InputStream into a ByteBuffer
     * 
     * @param input Input stream to read
     * @param useDirect Whether to use direct ByteBuffer
     * @return ByteBuffer containing all data
     * @throws IOException If reading fails
     */
    public static ByteBuffer readAll(InputStream input, boolean useDirect) throws IOException {
        ByteBufferOutputStream output = new ByteBufferOutputStream(useDirect);
        byte[] buffer = new byte[DEFAULT_BUFFER_SIZE];
        
        int bytesRead;
        while ((bytesRead = input.read(buffer)) != -1) {
            output.write(buffer, 0, bytesRead);
        }
        
        return output.getBuffer(true);
    }
    
    /**
     * Read a file into a ByteBuffer
     * 
     * @param path File to read
     * @param useDirect Whether to use direct ByteBuffer
     * @return ByteBuffer containing file contents
     * @throws IOException If reading fails
     */
    public static ByteBuffer readFile(Path path, boolean useDirect) throws IOException {
        long size = Files.size(path);
        
        if (size > MAX_BUFFER_SIZE) {
            // For very large files, read in chunks
            try (InputStream input = Files.newInputStream(path)) {
                return readAll(input, useDirect);
            }
        }
        
        // For smaller files, map directly
        ByteBuffer buffer = useDirect ? 
            ByteBuffer.allocateDirect((int) size) : 
            ByteBuffer.allocate((int) size);
        
        try (FileChannel channel = FileChannel.open(path, StandardOpenOption.READ)) {
            while (buffer.hasRemaining()) {
                if (channel.read(buffer) == -1) {
                    break;
                }
            }
        }
        
        buffer.flip();
        return buffer;
    }
    
    /**
     * Copy data from an InputStream to an OutputStream
     * 
     * @param input Source stream
     * @param output Destination stream
     * @return Number of bytes copied
     * @throws IOException If copying fails
     */
    public static long copy(InputStream input, OutputStream output) throws IOException {
        byte[] buffer = new byte[DEFAULT_BUFFER_SIZE];
        long totalBytes = 0;
        int bytesRead;
        
        while ((bytesRead = input.read(buffer)) != -1) {
            output.write(buffer, 0, bytesRead);
            totalBytes += bytesRead;
        }
        
        return totalBytes;
    }
    
    /**
     * Read a specific number of bytes from an InputStream
     * 
     * @param input Source stream
     * @param length Number of bytes to read
     * @return Byte array with read data
     * @throws IOException If reading fails or stream ends early
     */
    public static byte[] readBytes(InputStream input, int length) throws IOException {
        byte[] buffer = new byte[length];
        int offset = 0;
        
        while (offset < length) {
            int bytesRead = input.read(buffer, offset, length - offset);
            if (bytesRead == -1) {
                throw new EOFException("Unexpected end of stream after " + offset + " bytes");
            }
            offset += bytesRead;
        }
        
        return buffer;
    }
    
    /**
     * Check if a file exists and is readable
     * 
     * @param path Path to check
     * @return True if file exists and is readable
     */
    public static boolean isReadable(Path path) {
        return Files.exists(path) && Files.isReadable(path);
    }
    
    /**
     * Ensure parent directories exist
     * 
     * @param path Path whose parents should be created
     * @throws IOException If directory creation fails
     */
    public static void ensureParentDirectories(Path path) throws IOException {
        Path parent = path.getParent();
        if (parent != null && !Files.exists(parent)) {
            Files.createDirectories(parent);
        }
    }
}
