package cosmic.client.io;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.Charset;
import java.nio.charset.CharsetEncoder;
import java.nio.charset.StandardCharsets;

/**
 * OutputStream implementation backed by a dynamically growing ByteBuffer.
 * 
 * Deobfuscated from original class 'aC'.
 * 
 * This class provides:
 * - Automatic buffer expansion
 * - Support for character encoding via Appendable interface
 * - Efficient byte array operations
 */
public class ByteBufferOutputStream extends OutputStream implements Appendable {
    
    /** Default initial buffer capacity */
    private static final int DEFAULT_INITIAL_CAPACITY = 4096;
    
    /** Whether to use direct buffers */
    private final boolean useDirect;
    
    /** Initial capacity for buffer allocation */
    private final int initialCapacity;
    
    /** The backing ByteBuffer */
    private ByteBuffer buffer;
    
    /** Character set for text encoding */
    private final Charset charset;
    
    /** Encoder for character data */
    private CharsetEncoder encoder;
    
    /** Counter for statistics/debugging */
    public static int operationCount;
    
    /**
     * Create a new ByteBufferOutputStream with default settings
     * 
     * @param useDirect Whether to allocate direct ByteBuffers
     */
    public ByteBufferOutputStream(boolean useDirect) {
        this(useDirect, DEFAULT_INITIAL_CAPACITY);
    }
    
    /**
     * Create a new ByteBufferOutputStream with specified capacity
     * 
     * @param useDirect Whether to allocate direct ByteBuffers
     * @param initialCapacity Initial buffer capacity
     */
    public ByteBufferOutputStream(boolean useDirect, int initialCapacity) {
        this(useDirect, initialCapacity, StandardCharsets.UTF_8);
    }
    
    /**
     * Create a new ByteBufferOutputStream with full configuration
     * 
     * @param useDirect Whether to allocate direct ByteBuffers
     * @param initialCapacity Initial buffer capacity
     * @param charset Character set for text encoding
     */
    public ByteBufferOutputStream(boolean useDirect, int initialCapacity, Charset charset) {
        this.useDirect = useDirect;
        this.initialCapacity = initialCapacity > 0 ? initialCapacity : DEFAULT_INITIAL_CAPACITY;
        this.charset = charset;
        this.buffer = allocateBuffer(this.initialCapacity);
    }
    
    /**
     * Allocate a new buffer with the specified capacity
     * 
     * @param capacity Capacity to allocate
     * @return New ByteBuffer
     */
    private ByteBuffer allocateBuffer(int capacity) {
        return useDirect ? ByteBuffer.allocateDirect(capacity) : ByteBuffer.allocate(capacity);
    }
    
    /**
     * Ensure the buffer has at least the specified capacity
     * 
     * @param minCapacity Minimum required capacity
     */
    private void ensureCapacity(int minCapacity) {
        if (buffer.remaining() < minCapacity) {
            int newCapacity = Math.max(buffer.capacity() * 2, buffer.position() + minCapacity);
            ByteBuffer newBuffer = allocateBuffer(newCapacity);
            buffer.flip();
            newBuffer.put(buffer);
            buffer = newBuffer;
        }
    }
    
    @Override
    public void write(int b) throws IOException {
        ensureCapacity(1);
        buffer.put((byte) b);
    }
    
    @Override
    public void write(byte[] bytes, int offset, int length) throws IOException {
        ensureCapacity(length);
        buffer.put(bytes, offset, length);
    }
    
    /**
     * Write a ByteBuffer's contents to this stream
     * 
     * @param source Source buffer to read from
     */
    public void write(ByteBuffer source) {
        ensureCapacity(source.remaining());
        buffer.put(source);
    }
    
    /**
     * Get a ByteBuffer with the specified additional capacity
     * 
     * @param additionalCapacity Additional capacity needed
     * @return Buffer positioned at current write position
     */
    public ByteBuffer getBufferForWriting(int additionalCapacity) {
        ensureCapacity(additionalCapacity);
        return buffer;
    }
    
    /**
     * Reset the stream, optionally clearing the buffer
     * 
     * @param clear If true, allocate a new buffer; otherwise just reset position
     */
    public void reset(boolean clear) {
        if (clear) {
            buffer = allocateBuffer(initialCapacity);
        } else {
            buffer.clear();
        }
    }
    
    /**
     * Get the current buffer contents
     * 
     * @param flip If true, flip the buffer for reading
     * @return ByteBuffer with current contents
     */
    public ByteBuffer getBuffer(boolean flip) {
        if (flip) {
            buffer.flip();
        }
        return buffer;
    }
    
    @Override
    public Appendable append(CharSequence csq) throws IOException {
        if (csq == null) {
            csq = "null";
        }
        return append(csq, 0, csq.length());
    }
    
    @Override
    public Appendable append(CharSequence csq, int start, int end) throws IOException {
        if (csq == null) {
            csq = "null";
        }
        CharBuffer charBuffer = CharBuffer.wrap(csq, start, end);
        encodeCharBuffer(charBuffer);
        return this;
    }
    
    @Override
    public Appendable append(char c) throws IOException {
        CharBuffer charBuffer = CharBuffer.wrap(new char[]{c});
        encodeCharBuffer(charBuffer);
        return this;
    }
    
    /**
     * Encode a CharBuffer and write to the stream
     * 
     * @param charBuffer Characters to encode
     */
    private void encodeCharBuffer(CharBuffer charBuffer) throws IOException {
        if (encoder == null) {
            encoder = charset.newEncoder();
        }
        
        // Estimate required bytes
        int estimatedBytes = (int) (charBuffer.remaining() * encoder.averageBytesPerChar()) + 10;
        ensureCapacity(estimatedBytes);
        
        encoder.reset();
        encoder.encode(charBuffer, buffer, true);
        encoder.flush(buffer);
    }
    
    @Override
    public String toString() {
        ByteBuffer copy = buffer.duplicate();
        copy.flip();
        byte[] bytes = new byte[copy.remaining()];
        copy.get(bytes);
        return new String(bytes, charset);
    }
    
    /**
     * Get the current size of written data
     * 
     * @return Number of bytes written
     */
    public int size() {
        return buffer.position();
    }
    
    /**
     * Get the current capacity
     * 
     * @return Buffer capacity
     */
    public int capacity() {
        return buffer.capacity();
    }
}
