package cosmic.client.io;

import java.io.InputStream;
import java.nio.ByteBuffer;

/**
 * InputStream implementation backed by a ByteBuffer.
 * 
 * Deobfuscated from original class 'c'.
 * 
 * This class provides efficient reading from ByteBuffer data.
 */
public class ByteBufferInputStream extends InputStream {
    
    /** The backing ByteBuffer */
    public final ByteBuffer buffer;
    
    /** Mark position for reset functionality */
    private int markPosition = -1;
    
    /**
     * Create a new ByteBufferInputStream
     * 
     * @param buffer The ByteBuffer to read from
     */
    public ByteBufferInputStream(ByteBuffer buffer) {
        this.buffer = buffer.duplicate();
    }
    
    @Override
    public int read() {
        if (!buffer.hasRemaining()) {
            return -1;
        }
        return buffer.get() & 0xFF;
    }
    
    @Override
    public int read(byte[] bytes, int offset, int length) {
        if (!buffer.hasRemaining()) {
            return -1;
        }
        
        int toRead = Math.min(length, buffer.remaining());
        buffer.get(bytes, offset, toRead);
        return toRead;
    }
    
    @Override
    public long skip(long n) {
        if (n <= 0) {
            return 0;
        }
        
        int toSkip = (int) Math.min(n, buffer.remaining());
        buffer.position(buffer.position() + toSkip);
        return toSkip;
    }
    
    @Override
    public int available() {
        return buffer.remaining();
    }
    
    @Override
    public void mark(int readLimit) {
        markPosition = buffer.position();
    }
    
    @Override
    public void reset() {
        if (markPosition >= 0) {
            buffer.position(markPosition);
        }
    }
    
    @Override
    public boolean markSupported() {
        return true;
    }
    
    @Override
    public void close() {
        // Nothing to close for a ByteBuffer
    }
    
    /**
     * Get the underlying ByteBuffer
     * 
     * @return The ByteBuffer
     */
    public ByteBuffer getBuffer() {
        return buffer;
    }
    
    /**
     * Get remaining bytes as array
     * 
     * @return Remaining bytes
     */
    public byte[] toByteArray() {
        ByteBuffer copy = buffer.duplicate();
        byte[] result = new byte[copy.remaining()];
        copy.get(result);
        return result;
    }
}
