package cosmic.client.io;

import java.io.*;
import java.util.zip.GZIPInputStream;
import java.util.zip.Inflater;
import java.util.zip.InflaterInputStream;

/**
 * Extended GZIP/Deflate InputStream for Pack200 decompression.
 * 
 * Deobfuscated from original class 'ao'.
 * 
 * This class handles:
 * - GZIP decompression
 * - Raw deflate decompression
 * - Buffered reading with optional progress tracking
 */
public class GZipInputStream extends InputStream {
    
    /** Underlying decompression stream */
    private InputStream decompressStream;
    
    /** Original source stream */
    private final InputStream sourceStream;
    
    /** Buffer size for reading */
    private final int bufferSize;
    
    /** Whether to use GZIP format (vs raw deflate) */
    private final boolean useGzip;
    
    /** Progress tracker (optional) */
    private ProgressTracker progressTracker;
    
    /** Flag indicating if stream is closed */
    private boolean closed;
    
    /** Buffered exception for deferred error handling */
    private IOException deferredException;
    
    /** Read buffer */
    private final byte[] readBuffer;
    
    /**
     * Create a new GZipInputStream
     * 
     * @param source Source input stream
     * @param bufferSize Buffer size (-1 for default)
     * @param useGzip True for GZIP format, false for raw deflate
     */
    public GZipInputStream(InputStream source, int bufferSize, boolean useGzip) {
        this(source, bufferSize, useGzip, null);
    }
    
    /**
     * Create a new GZipInputStream with progress tracking
     * 
     * @param source Source input stream
     * @param bufferSize Buffer size (-1 for default)
     * @param useGzip True for GZIP format, false for raw deflate
     * @param progressTracker Optional progress tracker
     */
    public GZipInputStream(InputStream source, int bufferSize, boolean useGzip, 
                          ProgressTracker progressTracker) {
        this.sourceStream = source;
        this.bufferSize = bufferSize > 0 ? bufferSize : 8192;
        this.useGzip = useGzip;
        this.progressTracker = progressTracker;
        this.readBuffer = new byte[this.bufferSize];
        this.closed = false;
        
        initDecompressStream();
    }
    
    /**
     * Initialize the decompression stream
     */
    private void initDecompressStream() {
        try {
            if (useGzip) {
                // GZIP format includes header and CRC
                decompressStream = new GZIPInputStream(
                    new BufferedInputStream(sourceStream, bufferSize), bufferSize);
            } else {
                // Raw deflate format
                Inflater inflater = new Inflater(true); // nowrap = true for raw deflate
                decompressStream = new InflaterInputStream(
                    new BufferedInputStream(sourceStream, bufferSize), inflater, bufferSize);
            }
        } catch (IOException e) {
            deferredException = e;
        }
    }
    
    @Override
    public int read() throws IOException {
        checkException();
        if (decompressStream == null) {
            return -1;
        }
        
        int result = decompressStream.read();
        if (progressTracker != null && result != -1) {
            progressTracker.bytesRead(1);
        }
        return result;
    }
    
    @Override
    public int read(byte[] buffer, int offset, int length) throws IOException {
        checkException();
        if (decompressStream == null) {
            return -1;
        }
        
        int bytesRead = decompressStream.read(buffer, offset, length);
        if (progressTracker != null && bytesRead > 0) {
            progressTracker.bytesRead(bytesRead);
        }
        return bytesRead;
    }
    
    @Override
    public int available() throws IOException {
        checkException();
        if (decompressStream == null) {
            return 0;
        }
        return decompressStream.available();
    }
    
    @Override
    public void close() throws IOException {
        if (!closed) {
            closed = true;
            if (decompressStream != null) {
                try {
                    decompressStream.close();
                } finally {
                    // Also close the source if we own it
                    try {
                        sourceStream.close();
                    } catch (IOException ignored) {
                        // Ignore close errors on source
                    }
                }
            }
        }
    }
    
    /**
     * Check if there's a deferred exception to throw
     */
    private void checkException() throws IOException {
        if (deferredException != null) {
            throw deferredException;
        }
    }
    
    /**
     * Set the progress tracker
     * 
     * @param tracker Progress tracker to use
     */
    public void setProgressTracker(ProgressTracker tracker) {
        this.progressTracker = tracker;
    }
    
    /**
     * Interface for tracking decompression progress
     */
    public interface ProgressTracker {
        /**
         * Called when bytes are read
         * 
         * @param count Number of decompressed bytes read
         */
        void bytesRead(int count);
    }
}
