package cosmic.client.collections;

import java.util.Iterator;
import java.util.Spliterator;
import java.util.Spliterators;
import java.util.function.Consumer;
import java.util.function.UnaryOperator;

/**
 * Custom linked list implementation.
 * 
 * Deobfuscated from original class 'k'.
 * 
 * This is a doubly-linked list implementation with:
 * - Custom iteration support
 * - Efficient insertion/removal
 * - Support for forward and reverse traversal
 * 
 * @param <T> Element type
 */
public class LinkedList<T> implements Iterable<T> {
    
    /** Head sentinel node */
    public Node<T> head;
    
    /** Initial capacity (for array-backed variants) */
    public final int initialCapacity;
    
    /** Current size */
    public int size;
    
    /** Modification counter for concurrent modification detection */
    public static int modCount;
    
    /**
     * Create a new empty LinkedList.
     */
    public LinkedList() {
        this(16);
    }
    
    /**
     * Create a new LinkedList with specified initial capacity hint.
     * 
     * @param initialCapacity Initial capacity hint
     */
    public LinkedList(int initialCapacity) {
        this.initialCapacity = initialCapacity;
        this.head = null;
        this.size = 0;
    }
    
    /**
     * Create a new LinkedList with initial node.
     * 
     * @param initialNode Initial head node
     * @param size Initial size
     */
    public LinkedList(Node<T> initialNode, int size) {
        this.initialCapacity = 16;
        this.head = initialNode;
        this.size = size;
    }
    
    /**
     * Add an element to the end of the list.
     * 
     * @param node Node to add
     */
    public void addLast(Node<T> node) {
        if (head == null) {
            head = node;
            node.next = node;
            node.prev = node;
        } else {
            Node<T> tail = head.prev;
            tail.next = node;
            node.prev = tail;
            node.next = head;
            head.prev = node;
        }
        size++;
        modCount++;
    }
    
    /**
     * Insert a node before another node.
     * 
     * @param existingNode Node to insert before
     * @param newNode Node to insert
     */
    public void insertBefore(Node<T> existingNode, Node<T> newNode) {
        newNode.prev = existingNode.prev;
        newNode.next = existingNode;
        existingNode.prev.next = newNode;
        existingNode.prev = newNode;
        
        if (existingNode == head) {
            head = newNode;
        }
        
        size++;
        modCount++;
    }
    
    /**
     * Check if list contains a node.
     * 
     * @param node Node to check
     * @return True if node is in list
     */
    public boolean contains(Node<T> node) {
        if (head == null || node == null) {
            return false;
        }
        
        Node<T> current = head;
        do {
            if (current == node) {
                return true;
            }
            current = current.next;
        } while (current != head);
        
        return false;
    }
    
    /**
     * Get the first node.
     * 
     * @return Head node
     */
    public Node<T> getFirst() {
        return head;
    }
    
    /**
     * Remove and return the first node.
     * 
     * @param node Node to remove
     * @return Removed node
     */
    public Node<T> remove(Node<T> node) {
        if (size == 1) {
            head = null;
        } else {
            node.prev.next = node.next;
            node.next.prev = node.prev;
            
            if (node == head) {
                head = node.next;
            }
        }
        
        node.next = null;
        node.prev = null;
        size--;
        modCount++;
        
        return node;
    }
    
    /**
     * Find a node by value.
     * 
     * @param node Node with value to find
     * @return Found node or null
     */
    public Node<T> find(Node<T> node) {
        if (head == null) {
            return null;
        }
        
        Node<T> current = head;
        do {
            if (current.equals(node)) {
                return current;
            }
            current = current.next;
        } while (current != head);
        
        return null;
    }
    
    /**
     * Check if node exists in list.
     * 
     * @param node Node to check
     * @return True if found
     */
    public boolean exists(Node<T> node) {
        return find(node) != null;
    }
    
    /**
     * Get list size.
     * 
     * @return Number of elements
     */
    public int size() {
        return size;
    }
    
    @Override
    public Iterator<T> iterator() {
        return new LinkedListIterator<>(head, 
            node -> node.next, 
            node -> { /* no-op */ });
    }
    
    @Override
    public Spliterator<T> spliterator() {
        return Spliterators.spliterator(iterator(), size, Spliterator.ORDERED);
    }
    
    /**
     * Create an iterator with custom traversal functions.
     * 
     * @param start Starting node
     * @param nextFunction Function to get next node
     * @param onRemove Consumer called when removing
     * @return Iterator
     */
    public Iterator<T> createIterator(Node<T> start, 
                                      UnaryOperator<Node<T>> nextFunction, 
                                      Consumer<Node<T>> onRemove) {
        return new LinkedListIterator<>(start, nextFunction, onRemove);
    }
    
    @Override
    public int hashCode() {
        int hash = 0;
        if (head != null) {
            Node<T> current = head;
            do {
                hash = 31 * hash + (current.value != null ? current.value.hashCode() : 0);
                current = current.next;
            } while (current != head);
        }
        return hash;
    }
    
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("[");
        if (head != null) {
            Node<T> current = head;
            boolean first = true;
            do {
                if (!first) {
                    sb.append(", ");
                }
                sb.append(current.value);
                first = false;
                current = current.next;
            } while (current != head);
        }
        sb.append("]");
        return sb.toString();
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof LinkedList)) return false;
        
        LinkedList<?> other = (LinkedList<?>) obj;
        if (size != other.size) return false;
        
        if (head == null && other.head == null) return true;
        if (head == null || other.head == null) return false;
        
        Node<?> thisCurrent = head;
        Node<?> otherCurrent = other.head;
        
        do {
            if (!java.util.Objects.equals(thisCurrent.value, otherCurrent.value)) {
                return false;
            }
            thisCurrent = thisCurrent.next;
            otherCurrent = otherCurrent.next;
        } while (thisCurrent != head);
        
        return true;
    }
    
    /**
     * Node class for the linked list.
     * 
     * @param <E> Element type
     */
    public static class Node<E> {
        public E value;
        public Node<E> next;
        public Node<E> prev;
        
        public Node(E value) {
            this.value = value;
        }
    }
    
    /**
     * Iterator implementation for the linked list.
     * 
     * @param <E> Element type
     */
    private static class LinkedListIterator<E> implements Iterator<E> {
        private final Node<E> start;
        private Node<E> current;
        private final UnaryOperator<Node<E>> nextFunction;
        private final Consumer<Node<E>> onRemove;
        private boolean started;
        
        LinkedListIterator(Node<E> start, 
                          UnaryOperator<Node<E>> nextFunction,
                          Consumer<Node<E>> onRemove) {
            this.start = start;
            this.current = start;
            this.nextFunction = nextFunction;
            this.onRemove = onRemove;
            this.started = false;
        }
        
        @Override
        public boolean hasNext() {
            if (start == null) return false;
            if (!started) return true;
            return current != start;
        }
        
        @Override
        public E next() {
            if (!started) {
                started = true;
            }
            E value = current.value;
            current = nextFunction.apply(current);
            return value;
        }
        
        @Override
        public void remove() {
            if (onRemove != null) {
                onRemove.accept(current);
            }
        }
    }
}
