package cosmic.client.loader;

import java.io.IOException;

/**
 * Exception thrown when the loader encounters an error.
 * 
 * Deobfuscated from original class 'af'.
 * 
 * This exception is used to wrap various loading errors
 * and provide meaningful error messages.
 */
public class LoaderException extends IOException {
    
    private static final long serialVersionUID = 1L;
    
    /** Counter for tracking exception occurrences */
    public static int exceptionCount;
    
    /**
     * Create a new LoaderException with no message.
     */
    public LoaderException() {
        super();
        exceptionCount++;
    }
    
    /**
     * Create a new LoaderException with a message.
     * 
     * @param message Error message
     */
    public LoaderException(String message) {
        super(message);
        exceptionCount++;
    }
    
    /**
     * Create a new LoaderException with a message and cause.
     * 
     * @param message Error message
     * @param cause Underlying cause
     */
    public LoaderException(String message, Throwable cause) {
        super(message, cause);
        exceptionCount++;
    }
    
    /**
     * Create a new LoaderException with a cause.
     * 
     * @param cause Underlying cause
     */
    public LoaderException(Throwable cause) {
        super(cause);
        exceptionCount++;
    }
}
