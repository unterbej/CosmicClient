package cosmic.client.util;

import cosmic.client.io.ByteBufferOutputStream;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.ByteBuffer;

/**
 * Utility class for ByteBuffer operations.
 * 
 * Deobfuscated from original class 'y'.
 * 
 * Provides methods for:
 * - Copying ByteBuffers
 * - Writing ByteBuffers to OutputStreams
 * - Creating ByteBuffers from various sources
 */
public final class ByteBufferUtils {
    
    /** Thread-local buffer pool for temporary operations */
    public static final ThreadLocal<byte[]> THREAD_LOCAL_BUFFER = ThreadLocal.withInitial(() -> new byte[8192]);
    
    private ByteBufferUtils() {
        // Utility class - no instantiation
    }
    
    /**
     * Create a copy of a ByteBuffer.
     * 
     * @param source Source buffer to copy
     * @return New ByteBuffer with copied data
     */
    public static ByteBuffer copy(ByteBuffer source) {
        return copy(source, false);
    }
    
    /**
     * Create a copy of a ByteBuffer.
     * 
     * @param source Source buffer to copy
     * @param useDirect Whether to create a direct buffer
     * @return New ByteBuffer with copied data
     */
    public static ByteBuffer copy(ByteBuffer source, boolean useDirect) {
        ByteBuffer copy = source.duplicate();
        int size = copy.remaining();
        
        ByteBuffer dest = useDirect ? 
            ByteBuffer.allocateDirect(size) : 
            ByteBuffer.allocate(size);
        
        dest.put(copy);
        dest.flip();
        return dest;
    }
    
    /**
     * Create a ByteBuffer with the specified capacity.
     * 
     * @param capacity Capacity in bytes
     * @param useDirect Whether to create a direct buffer
     * @return New ByteBuffer
     */
    public static ByteBuffer create(int capacity, boolean useDirect) {
        return useDirect ? 
            ByteBuffer.allocateDirect(capacity) : 
            ByteBuffer.allocate(capacity);
    }
    
    /**
     * Write a ByteBuffer to an OutputStream.
     * 
     * @param buffer Buffer to write
     * @param output Output stream
     * @throws IOException If writing fails
     */
    public static void writeTo(ByteBuffer buffer, OutputStream output) throws IOException {
        ByteBuffer copy = buffer.duplicate();
        byte[] transferBuffer = THREAD_LOCAL_BUFFER.get();
        
        while (copy.hasRemaining()) {
            int toWrite = Math.min(copy.remaining(), transferBuffer.length);
            copy.get(transferBuffer, 0, toWrite);
            output.write(transferBuffer, 0, toWrite);
        }
    }
    
    /**
     * Convert a ByteBuffer to a byte array.
     * 
     * @param buffer Buffer to convert
     * @return Byte array with buffer contents
     */
    public static byte[] toByteArray(ByteBuffer buffer) {
        ByteBuffer copy = buffer.duplicate();
        byte[] result = new byte[copy.remaining()];
        copy.get(result);
        return result;
    }
    
    /**
     * Create a ByteBuffer from a byte array.
     * 
     * @param bytes Byte array
     * @param useDirect Whether to create a direct buffer
     * @return ByteBuffer wrapping or containing the bytes
     */
    public static ByteBuffer fromByteArray(byte[] bytes, boolean useDirect) {
        if (useDirect) {
            ByteBuffer buffer = ByteBuffer.allocateDirect(bytes.length);
            buffer.put(bytes);
            buffer.flip();
            return buffer;
        } else {
            return ByteBuffer.wrap(bytes);
        }
    }
    
    /**
     * Ensure a ByteBuffer has at least the specified remaining capacity.
     * 
     * @param buffer Buffer to check
     * @param required Required remaining capacity
     * @return Original buffer if sufficient, or a new larger buffer
     */
    public static ByteBuffer ensureCapacity(ByteBuffer buffer, int required) {
        if (buffer.remaining() >= required) {
            return buffer;
        }
        
        int newCapacity = Math.max(buffer.capacity() * 2, buffer.position() + required);
        ByteBuffer newBuffer = buffer.isDirect() ? 
            ByteBuffer.allocateDirect(newCapacity) : 
            ByteBuffer.allocate(newCapacity);
        
        buffer.flip();
        newBuffer.put(buffer);
        return newBuffer;
    }
    
    /**
     * Compare two ByteBuffers for equality.
     * 
     * @param a First buffer
     * @param b Second buffer
     * @return True if contents are equal
     */
    public static boolean equals(ByteBuffer a, ByteBuffer b) {
        if (a.remaining() != b.remaining()) {
            return false;
        }
        
        ByteBuffer aCopy = a.duplicate();
        ByteBuffer bCopy = b.duplicate();
        
        while (aCopy.hasRemaining()) {
            if (aCopy.get() != bCopy.get()) {
                return false;
            }
        }
        
        return true;
    }
}
