package net.minecraft.client.main;

import cosmic.client.crypto.AESCipher;
import cosmic.client.io.ByteBufferOutputStream;
import cosmic.client.io.ByteBufferInputStream;
import cosmic.client.io.FileUtils;
import cosmic.client.io.GZipInputStream;
import cosmic.client.pack200.Pack200Unpacker;
import cosmic.client.pack200.Pack200Factory;
import cosmic.client.pack200.Pack200Handler;

import com.sun.management.HotSpotDiagnosticMXBean;
import com.sun.management.VMOption;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import java.io.*;
import java.lang.management.ManagementFactory;
import java.lang.reflect.Method;
import java.net.URI;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.ByteBuffer;
import java.nio.file.Path;
import java.security.CodeSource;
import java.security.MessageDigest;
import java.security.ProtectionDomain;
import java.util.*;
import java.util.jar.JarOutputStream;

/**
 * CosmicClient Minecraft Launcher - Main Entry Point
 * 
 * This class is responsible for:
 * 1. Extracting the encrypted payload from the embedded resource 'b'
 * 2. Decrypting and decompressing the payload using AES + Pack200
 * 3. Creating a custom ClassLoader with the extracted classes
 * 4. Launching the actual Minecraft client
 * 
 * Deobfuscated and reconstructed from CosmicClient-1_8_9.jar
 * Original obfuscated class names have been replaced with meaningful names.
 */
public class Main {
    
    /** Hexadecimal character array for hash conversion */
    private static final char[] HEX_CHARS = {
        '0', '1', '2', '3', '4', '5', '6', '7',
        '8', '9', 'a', 'b', 'c', 'd', 'e', 'f'
    };
    
    /** Counter for tracking operations (used for timing/debugging) */
    public static int operationCounter;
    
    /** Encrypted key data - part 1 */
    private static final String[] ENCRYPTED_KEY_DATA_1;
    
    /** Encrypted key data - part 2 */
    private static final String[] ENCRYPTED_KEY_DATA_2;
    
    // Static initialization for encrypted keys
    static {
        // These would be initialized with the obfuscated string data
        // The original code uses complex XOR operations to hide the keys
        ENCRYPTED_KEY_DATA_1 = new String[16];
        ENCRYPTED_KEY_DATA_2 = new String[16];
        
        // Initialize the hex character array
        // (This is done in static initializer in original obfuscated code)
    }
    
    /**
     * Main entry point for CosmicClient
     * 
     * @param args Command line arguments passed to Minecraft
     */
    public static void main(String[] args) {
        try {
            // Step 1: Check JVM settings and disable compressed OOPs if needed
            checkAndConfigureJVM();
            
            // Step 2: Determine working directories
            File workingDir = getWorkingDirectory();
            File jarFile = getJarFile();
            File parentDir = jarFile.getParentFile();
            
            // Step 3: Set up native library path for LWJGL
            String nativePath = findNativesPath(parentDir, 0, System.currentTimeMillis());
            if (nativePath != null) {
                System.setProperty("org.lwjgl.librarypath", nativePath);
                System.setProperty("java.library.path", nativePath);
            }
            
            // Step 4: Load and decrypt the embedded payload
            ByteBuffer decryptedPayload = loadAndDecryptPayload();
            
            // Step 5: Extract classes from the payload
            ByteBuffer extractedJar = extractJarFromPayload(decryptedPayload);
            
            // Step 6: Write to temp file and create class loader
            File tempJar = createTempJarFile(extractedJar);
            
            // Step 7: Set up URLs for the class loader
            List<URL> urls = new LinkedList<>();
            urls.add(tempJar.toURI().toURL());
            
            // Add library jars from libs folder
            addLibraryJars(parentDir, urls);
            
            // Step 8: Create custom class loader
            URL[] urlArray = urls.toArray(new URL[urls.size()]);
            ClassLoader parentLoader = Main.class.getClassLoader().getParent();
            URLClassLoader customLoader = new URLClassLoader(urlArray, parentLoader);
            
            // Step 9: Set context class loader
            Thread.currentThread().setContextClassLoader(customLoader);
            
            // Step 10: Launch the actual Minecraft main class
            launchMinecraft(customLoader, args);
            
        } catch (Exception e) {
            System.err.println("Failed to launch CosmicClient: " + e.getMessage());
            e.printStackTrace();
            throw new RuntimeException("Launch failed", e);
        }
    }
    
    /**
     * Check JVM configuration and optimize settings
     */
    private static void checkAndConfigureJVM() {
        try {
            HotSpotDiagnosticMXBean bean = ManagementFactory.getPlatformMXBean(
                HotSpotDiagnosticMXBean.class
            );
            
            // Check UseCompressedOops setting
            VMOption option = bean.getVMOption("UseCompressedOops");
            if ("true".equals(option.getValue()) && option.isWriteable()) {
                // Could potentially modify, but typically not changeable at runtime
            }
        } catch (Exception ignored) {
            // Not critical if this fails
        }
    }
    
    /**
     * Get the working directory (usually .minecraft folder)
     */
    private static File getWorkingDirectory() {
        String userHome = System.getProperty("user.home");
        return new File(userHome);
    }
    
    /**
     * Get the JAR file that contains this class
     */
    private static File getJarFile() throws Exception {
        ProtectionDomain domain = Main.class.getProtectionDomain();
        CodeSource source = domain.getCodeSource();
        URL location = source.getLocation();
        URI uri = location.toURI();
        String path = uri.getPath();
        return new File(path);
    }
    
    /**
     * Find the natives directory path
     * 
     * @param baseDir Base directory to search from
     * @param depth Current search depth
     * @param timestamp Timestamp for validation
     * @return Path to natives directory, or null if not found
     */
    private static String findNativesPath(File baseDir, int depth, long timestamp) {
        // Search for natives folder in common locations
        String[] possibleNames = {"natives", "native", "bin"};
        
        for (String name : possibleNames) {
            File nativesDir = new File(baseDir, name);
            if (nativesDir.exists() && nativesDir.isDirectory()) {
                File[] files = nativesDir.listFiles();
                if (files != null && files.length > 0) {
                    return nativesDir.getAbsolutePath();
                }
            }
        }
        
        // Also check parent directories up to a certain depth
        if (depth < 3 && baseDir.getParentFile() != null) {
            return findNativesPath(baseDir.getParentFile(), depth + 1, timestamp);
        }
        
        return null;
    }
    
    /**
     * Load and decrypt the embedded payload from resource 'b'
     * 
     * @return Decrypted ByteBuffer containing the compressed JAR data
     */
    private static ByteBuffer loadAndDecryptPayload() throws Exception {
        // Load the encrypted resource
        InputStream resourceStream = Main.class.getResourceAsStream("/b");
        if (resourceStream == null) {
            throw new IllegalStateException("Encrypted payload resource 'b' not found");
        }
        
        try {
            // Read the entire resource into a ByteBuffer
            ByteBuffer encryptedData = FileUtils.readAll(resourceStream, true);
            
            // Compute the hash for verification
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            md.reset();
            md.update(encryptedData.duplicate());
            byte[] hash = md.digest();
            String hashString = bytesToHex(hash);
            
            // Decrypt using AES
            AESCipher cipher = new AESCipher(hashString, true);
            ByteBuffer decryptedData = cipher.decrypt(0, 0, 'A', encryptedData, true);
            
            return decryptedData;
        } finally {
            resourceStream.close();
        }
    }
    
    /**
     * Extract JAR from the decrypted and compressed payload
     * 
     * @param compressedData The decrypted but still compressed data
     * @return ByteBuffer containing the extracted JAR
     */
    private static ByteBuffer extractJarFromPayload(ByteBuffer compressedData) throws Exception {
        return unpackPayload((short) 0, (short) 0, 
            new ByteBufferInputStream(compressedData), 
            true, 0, true);
    }
    
    /**
     * Unpack payload using Pack200 decompression
     * 
     * @param param1 First parameter for unpacking configuration
     * @param param2 Second parameter for unpacking configuration
     * @param input Input stream with compressed data
     * @param useGzip Whether to use GZIP decompression
     * @param param4 Additional parameter
     * @param param5 Additional flag
     * @return Unpacked data as ByteBuffer
     */
    public static ByteBuffer unpackPayload(short param1, short param2, 
            InputStream input, boolean useGzip, int param4, boolean param5) throws Exception {
        
        // Compute configuration parameters from input values
        long config = ((long) param1 << 48) | ((long) param2 << 48 >>> 16) | ((long) param4 << 32 >>> 32);
        
        // XOR with magic constants to derive actual parameters
        long magic1 = config ^ 112218500967331L;
        int unpackParam1 = (int) (magic1 >>> 48);
        int unpackParam2 = (int) ((magic1 << 16) >>> 48);
        int unpackParam3 = (int) ((magic1 << 32) >>> 32);
        
        long magic2 = config ^ 60348117292003L;
        int streamParam1 = (int) (magic2 >>> 32);
        int streamParam2 = (int) ((magic2 << 32) >>> 48);
        int streamParam3 = (int) ((magic2 << 48) >>> 48);
        
        // Create output stream for unpacked data
        ByteBufferOutputStream outputStream = new ByteBufferOutputStream(param5);
        JarOutputStream jarOutput = new JarOutputStream(outputStream);
        jarOutput.setMethod(8); // DEFLATED
        jarOutput.setLevel(5);
        
        try {
            // Get the Pack200 handler
            Pack200Handler handler = Pack200Factory.createHandler(
                (char) unpackParam1, (short) unpackParam2, unpackParam3);
            
            if (useGzip) {
                // Use GZIP decompression
                GZipInputStream gzipInput = new GZipInputStream(input, -1, false);
                try {
                    handler.unpack(streamParam1, gzipInput, (char) streamParam2, 
                        streamParam3, jarOutput);
                } finally {
                    gzipInput.close();
                }
            } else {
                // Direct unpacking
                handler.unpack(streamParam1, input, (char) streamParam2, 
                    streamParam3, jarOutput);
            }
        } finally {
            jarOutput.close();
        }
        
        return outputStream.getBuffer(false);
    }
    
    /**
     * Create a temporary JAR file from the extracted data
     * 
     * @param jarData ByteBuffer containing JAR data
     * @return Temporary File object
     */
    private static File createTempJarFile(ByteBuffer jarData) throws Exception {
        File tempFile = File.createTempFile("cosmic_", ".jar");
        tempFile.deleteOnExit();
        
        Path tempPath = tempFile.toPath();
        FileUtils.writeToFile(tempPath, jarData);
        
        return tempFile;
    }
    
    /**
     * Add library JARs from the libs folder to the URL list
     * 
     * @param baseDir Base directory
     * @param urls List to add URLs to
     */
    private static void addLibraryJars(File baseDir, List<URL> urls) throws Exception {
        File libsDir = new File(baseDir, "libs");
        if (libsDir.exists() && libsDir.isDirectory()) {
            File[] files = libsDir.listFiles();
            if (files != null) {
                for (File file : files) {
                    String name = file.getName();
                    if (name.endsWith(".jar")) {
                        urls.add(file.toURI().toURL());
                    }
                }
            }
        }
    }
    
    /**
     * Launch the actual Minecraft client
     * 
     * @param classLoader The custom class loader with extracted classes
     * @param args Command line arguments
     */
    private static void launchMinecraft(ClassLoader classLoader, String[] args) throws Exception {
        // The actual main class to launch (typically the Minecraft main class or a custom one)
        String mainClassName = "net.minecraft.client.Minecraft";
        
        // Try alternative class names if the default doesn't exist
        String[] possibleMainClasses = {
            "net.minecraft.client.Minecraft",
            "net.minecraft.client.main.Main",
            "cosmic.client.CosmicClient",
            "Start"
        };
        
        Class<?> mainClass = null;
        for (String className : possibleMainClasses) {
            try {
                mainClass = classLoader.loadClass(className);
                break;
            } catch (ClassNotFoundException ignored) {
                // Try next class name
            }
        }
        
        if (mainClass == null) {
            throw new ClassNotFoundException("Could not find main class to launch");
        }
        
        // Find and invoke the main method
        Method mainMethod = mainClass.getMethod("main", String[].class);
        mainMethod.invoke(null, (Object) args);
    }
    
    /**
     * Convert byte array to hexadecimal string
     * 
     * @param bytes Input byte array
     * @return Hexadecimal string representation
     */
    public static String bytesToHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder(bytes.length * 2);
        for (byte b : bytes) {
            sb.append(HEX_CHARS[(b >>> 4) & 0x0F]);
            sb.append(HEX_CHARS[b & 0x0F]);
        }
        return sb.toString();
    }
}
